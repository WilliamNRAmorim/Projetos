# Cue sheet — trilha e efeitos do filme GMS

30 fps · 120 BPM · 62 s. Cada linha = um som sincronizado com a imagem.

| Tempo | Quadro | Camada | O que toca |
|---|---|---|---|
|   0.00 s |    0 | música | pad em Lá menor entra (Am–F–C–G, 1 acorde por compasso de 2 s) |
|   0.05 s |    2 | sfx | farfalhar de papel (folhas) |
|   0.90 s |   27 | sfx | riser curto até o ponto vermelho nascer |
|   1.87 s |   56 | sfx | whoosh: ponto queima o papel (frames 56–70) |
|   2.00 s |   60 | sfx | ponto vermelho nasce (frame 60): hit + sub |
|   2.55 s |   76 | sfx | dois pings de abertura: "From paper to live data." |
|   3.88 s |  116 | sfx | whoosh de corte → S02 (flood) + hit no corte |
|   4.00 s |  120 | sfx | flash "PAPERLESS": hit + palma + nota 1/6 subindo |
|   5.00 s |  150 | sfx | flash "TRACEABLE": hit + palma + nota 2/6 subindo |
|   6.00 s |  180 | sfx | flash "LIVE": hit + palma + nota 3/6 subindo |
|   7.00 s |  210 | sfx | flash "8 STAGES": hit + palma + nota 4/6 subindo |
|   8.00 s |  240 | sfx | flash "HOUR BY HOUR": hit + palma + nota 5/6 subindo |
|   9.00 s |  270 | sfx | flash "€0 CAPEX": hit + palma + nota 6/6 subindo |
|   9.88 s |  296 | sfx | whoosh de corte → S03 (iris) + hit no corte |
|  12.50 s |  375 | sfx | Onda 2: whoosh curto + hit |
|  15.50 s |  465 | sfx | Onda 3: whoosh curto + hit |
|  15.73 s |  472 | sfx | chips verdes "✓ 2.854 achados" e "✓ 20 defeitos": ding duplo |
|  18.00 s |  540 | sfx | HOJE: whoosh curto + hit |
|  18.30 s |  549 | sfx | teclas de digitação (campos da Trançagem) |
|  19.88 s |  596 | sfx | whoosh de corte → S04 (portal) + hit no corte |
|  20.28 s |  608 | sfx | S04: título entra (ping) + tela sobe (whoosh leve) |
|  21.40 s |  642 | sfx | S04: digita a OP (8 teclas) · seleciona carretel · Start |
|  25.88 s |  776 | sfx | whoosh de corte → S05 (flood) + hit no corte |
|  26.28 s |  788 | sfx | S05: título entra (ping) + tela sobe (whoosh leve) |
|  29.00 s |  870 | sfx | S05: alerta (dois bips graves) — "THXX parada sem motivo" |
|  31.88 s |  956 | sfx | whoosh de corte → S06 (iris) + hit no corte |
|  32.28 s |  968 | sfx | S06: título entra (ping) + tela sobe (whoosh leve) |
|  33.00 s |  990 | sfx | S06: escala de 8 notas, uma por etapa |
|  37.88 s | 1136 | sfx | whoosh de corte → S07 (portal) + hit no corte |
|  38.28 s | 1148 | sfx | S07: título entra (ping) + tela sobe (whoosh leve) |
|  40.00 s | 1200 | sfx | S07: alerta · abre motivos · escolhe "Reel change" · Close shift (confirmação) |
|  43.88 s | 1316 | sfx | whoosh de corte → S08 (flood) + hit no corte |
|  44.00 s | 1320 | sfx | S08: número 1/4 — swell reverso + impacto |
|  44.15 s | 1324 | sfx | S08: contagem 0→36× — varredura de tom + 14 ticks |
|  46.00 s | 1380 | sfx | S08: número 2/4 — swell reverso + impacto |
|  48.00 s | 1440 | sfx | S08: número 3/4 — swell reverso + impacto |
|  49.60 s | 1488 | sfx | riser longo (2,4 s) até o corte do fecho |
|  50.00 s | 1500 | sfx | S08: número 4/4 — swell reverso + impacto |
|  52.00 s | 1560 | música | S08 termina; pulso baixo + pad; em 57,0 tudo cai para só o pad (silêncio dramático) |
|  52.00 s | 1560 | sfx | S09 entra: impacto grave + crash + whoosh |
|  53.00 s | 1590 | sfx | S09: etapa 1/8 do carretel — nota 1 da escala subindo |
|  53.50 s | 1605 | sfx | S09: etapa 2/8 do carretel — nota 2 da escala subindo |
|  54.00 s | 1620 | sfx | S09: etapa 3/8 do carretel — nota 3 da escala subindo |
|  54.50 s | 1635 | sfx | S09: etapa 4/8 do carretel — nota 4 da escala subindo |
|  55.00 s | 1650 | sfx | S09: etapa 5/8 do carretel — nota 5 da escala subindo |
|  55.50 s | 1665 | sfx | S09: etapa 6/8 do carretel — nota 6 da escala subindo |
|  56.00 s | 1680 | sfx | S09: etapa 7/8 do carretel — nota 7 da escala subindo |
|  56.50 s | 1695 | sfx | S09: etapa 8/8 do carretel — nota 8 da escala subindo |
|  57.00 s | 1710 | sfx | S09: "Paper forgets." — queda grave, música some |
|  58.00 s | 1740 | sfx | S09: letra G entra — hit + nota |
|  58.50 s | 1755 | sfx | S09: letra M entra — hit + nota |
|  59.00 s | 1770 | sfx | S09: letra S entra — hit + nota |
|  59.50 s | 1785 | sfx | S09: "remembers." — acorde de Lá menor + impacto + crash; cauda até 62 s |
