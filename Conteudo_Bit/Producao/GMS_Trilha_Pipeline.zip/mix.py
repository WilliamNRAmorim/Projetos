#!/usr/bin/env python3
"""
GMS · mixagem final: voz + música + efeitos -> áudio -> vídeo.

Uso:
  python3 mix.py --voz /pasta/com/S01.m4a ... S09.m4a --video ../out/GMS_Filme_EN_9x16_1080p_mudo.mp4 ../out/GMS_Filme_EN_16x9_1080p_mudo.mp4
  python3 mix.py --sem-voz --video ...            # prévia só com música + efeitos

Regras:
  - cada bloco Sxx é aparado (silêncio no início/fim), tratado (filtro 80 Hz, compressor, presença) e
    posicionado no início da sua cena (+ ajuste fino em OFFSETS);
  - se passar da janela da cena, acelera no máximo 14 % (sem mudar o tom); se ainda passar, avisa;
  - a música e os efeitos abaixam sozinhos (ducking) quando você fala;
  - master em −16 LUFS / −1 dBTP; o vídeo é copiado sem re-renderizar (-c:v copy).
"""
import argparse, glob, json, os, subprocess, sys, tempfile
import numpy as np
from scipy.io import wavfile
from scipy.signal import lfilter

SR = 44100
HERE = os.path.dirname(os.path.abspath(__file__))

# (início s, janela s) por cena, de theme.ts
CENAS = {
    'S01': (0.0, 4.0), 'S02': (4.0, 6.0), 'S03': (10.0, 10.0), 'S04': (20.0, 6.0), 'S05': (26.0, 6.0),
    'S06': (32.0, 6.0), 'S07': (38.0, 6.0), 'S08': (44.0, 8.0), 'S09': (52.0, 10.0),
}
# ajuste fino do ponto onde a fala começa (s depois do início da cena)
OFFSETS = {'S01': 0.25, 'S02': 0.10, 'S03': 0.25, 'S04': 0.45, 'S05': 0.45, 'S06': 0.45, 'S07': 0.45, 'S08': 0.10, 'S09': 4.90}
# S09: "Paper forgets" cai em 57,0 s e "remembers" em 59,5 s -> a fala começa ~56,9 s (52 + 4,9)
MAX_SPEED = 1.14

# MODO BATIDA (opcional): frases curtas caem exatamente nos hits. Se existir o arquivo S02_1.m4a etc.,
# ele vale no lugar do bloco inteiro da cena. (início absoluto s, fim máximo s)
BATIDA = {
    'S02': [('S02_1', 3.94, 4.95), ('S02_2', 4.94, 5.95), ('S02_3', 5.94, 6.95),
            ('S02_4', 6.94, 7.95), ('S02_5', 7.94, 8.95), ('S02_6', 8.94, 10.0)],
    'S08': [('S08_1', 44.05, 45.95), ('S08_2', 45.94, 47.95), ('S08_3', 47.94, 49.95), ('S08_4', 49.94, 52.0)],
    'S09': [('S09_1', 56.94, 57.95), ('S09_2', 57.94, 59.40), ('S09_3', 59.44, 62.0)],
}


def run(cmd, **kw):
    r = subprocess.run(cmd, capture_output=True, text=True, **kw)
    if r.returncode:
        sys.exit(f"ffmpeg falhou:\n{' '.join(cmd)}\n{r.stderr[-1500:]}")
    return r


def load_mono(path, af=''):
    with tempfile.TemporaryDirectory() as td:
        out = f"{td}/x.wav"
        cmd = ['ffmpeg', '-v', 'error', '-y', '-i', path, '-ac', '1', '-ar', str(SR)]
        if af: cmd += ['-af', af]
        run(cmd + [out])
        sr, d = wavfile.read(out)
    return d.astype(np.float64) / (32768.0 if d.dtype == np.int16 else 1.0)


def trim(x, thr_db=-42, pad=0.06):
    a = np.abs(x); w = int(SR * 0.01)
    env = np.convolve(a, np.ones(w) / w, mode='same')
    thr = 10 ** (thr_db / 20) * max(env.max(), 1e-6) ** 0.0  # limiar absoluto
    idx = np.where(env > max(thr, env.max() * 10 ** (-30 / 20)))[0]
    if len(idx) == 0: return x
    i0 = max(0, idx[0] - int(pad * SR)); i1 = min(len(x), idx[-1] + int(pad * SR))
    return x[i0:i1]


def stretch(x, speed):
    """acelera sem mudar o tom (atempo do ffmpeg)."""
    with tempfile.TemporaryDirectory() as td:
        a = f"{td}/a.wav"; b = f"{td}/b.wav"
        wavfile.write(a, SR, (np.clip(x, -1, 1) * 32767).astype(np.int16))
        run(['ffmpeg', '-v', 'error', '-y', '-i', a, '-af', f'atempo={speed:.4f}', b])
        _, d = wavfile.read(b)
    return d.astype(np.float64) / 32768.0


VOZ_AF = ('highpass=f=90,lowpass=f=15000,adeclick,'
          'acompressor=threshold=-26dB:ratio=4.5:attack=4:release=70:makeup=5,'
          'equalizer=f=180:t=q:w=1.0:g=2.0,equalizer=f=350:t=q:w=1.2:g=-2.5,'
          'equalizer=f=3500:t=q:w=1.0:g=3.5,equalizer=f=9000:t=h:w=0.7:g=2.5,'
          'acompressor=threshold=-14dB:ratio=2.5:attack=2:release=40,'
          'loudnorm=I=-18:TP=-2:LRA=5')


def env_follow(x, atk=0.025, rel=0.28):
    a = np.abs(x)
    ca = np.exp(-1 / (atk * SR)); cr = np.exp(-1 / (rel * SR))
    out = np.zeros_like(a); e = 0.0
    # laço vetorizado por blocos para velocidade
    for i in range(0, len(a), 4096):
        seg = a[i:i + 4096]
        for j, v in enumerate(seg):
            e = ca * e + (1 - ca) * v if v > e else cr * e + (1 - cr) * v
            out[i + j] = e
    return out


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--voz', help='pasta com S01..S09 (.m4a .wav .mp3 .aac .ogg)')
    ap.add_argument('--sem-voz', action='store_true')
    ap.add_argument('--video', nargs='*', default=[])
    ap.add_argument('--saida', default=os.path.join(HERE, '..', 'out', 'final'))
    ap.add_argument('--musica-db', type=float, default=0.0, help='ajuste do nível da música (dB)')
    ap.add_argument('--sfx-db', type=float, default=0.0, help='ajuste do nível dos efeitos (dB)')
    ap.add_argument('--offset', nargs='*', default=[], help='ex.: S09=56.7  (início absoluto em segundos)')
    ap.add_argument('--sufixo', default='')
    a = ap.parse_args()
    os.makedirs(a.saida, exist_ok=True)

    sr, M = wavfile.read(f"{HERE}/stems/music.wav"); M = M.astype(np.float64) / 32768
    sr, X = wavfile.read(f"{HERE}/stems/sfx.wav"); X = X.astype(np.float64) / 32768
    N = len(M)
    V = np.zeros(N)
    abs_off = {k: float(v) for k, v in (s.split('=') for s in a.offset)}
    rel = []

    if a.voz and not a.sem_voz:
        def achar(nome):
            return [f for ext in ('m4a', 'wav', 'mp3', 'aac', 'ogg', 'flac', 'opus')
                    for f in glob.glob(f"{a.voz}/{nome}.{ext}") + glob.glob(f"{a.voz}/{nome.lower()}.{ext}")]

        def colocar(nome, path, start, fim):
            nonlocal V
            x = trim(load_mono(path, VOZ_AF))
            avail = fim - start - 0.12
            d = len(x) / SR; note = ''
            if d > avail:
                speed = min(MAX_SPEED, d / avail)
                x = stretch(x, speed); d = len(x) / SR
                note = f"acelerado {100 * (speed - 1):.0f}%"
                if d > avail + 0.05: note += f" · AINDA PASSA {d - avail:.2f}s (regrave mais rápido)"
            i = int(start * SR)
            V[i:i + len(x)] += x[:max(0, N - i)]
            rel.append(f"{nome}: {os.path.basename(path)} · {d:.2f}s em {start:.2f}s (até {fim:.1f}s) {note}")

        for sid, (t0, win) in CENAS.items():
            subs = [(n, st, fi, achar(n)) for n, st, fi in BATIDA.get(sid, [])]
            subs = [x for x in subs if x[3]]
            if subs:                                   # modo batida
                for n, st, fi, fs in subs:
                    colocar(n, fs[0], abs_off.get(n, st), fi)
                continue
            fs = achar(sid)
            if not fs:
                rel.append(f"{sid}: (sem arquivo)")
                continue
            colocar(sid, fs[0], abs_off.get(sid, t0 + OFFSETS[sid]), t0 + win + 0.15)

        # acabamento de "voz de vídeo": saturação leve + sala curta (brilho e corpo sem eco perceptível)
        if V.any():
            sat = np.tanh(V * 2.2) / 2.2
            V = 0.82 * V + 0.18 * sat
            ir = np.random.default_rng(3).standard_normal(int(SR * 0.45)) * np.exp(-np.arange(int(SR * 0.45)) / (SR * 0.09))
            ir[: int(SR * 0.012)] = 0
            from scipy.signal import fftconvolve
            wet = fftconvolve(V, ir / np.sqrt((ir ** 2).sum()))[:N]
            V = V + 0.10 * wet

    # ducking: música abaixa ~ −9 dB, efeitos ~ −4 dB enquanto há voz
    if V.any():
        e = env_follow(V)
        e = np.clip(e / (np.percentile(e[e > 1e-4], 90) if (e > 1e-4).any() else 1), 0, 1)
        dm = 1 - 0.65 * e; dx = 1 - 0.38 * e
    else:
        dm = dx = np.ones(N)

    g = lambda db: 10 ** (db / 20)
    mix = V * g(0) + M[:, 0] * dm * g(a.musica_db - 1.5) + X[:, 0] * dx * g(a.sfx_db)
    mixR = V * g(0) + M[:, 1] * dm * g(a.musica_db - 1.5) + X[:, 1] * dx * g(a.sfx_db)
    st = np.stack([mix, mixR], 1)
    st /= max(1.0, np.max(np.abs(st)) / 0.95)

    with tempfile.TemporaryDirectory() as td:
        raw = f"{td}/mix.wav"
        wavfile.write(raw, SR, (st * 32767).astype(np.int16))
        # loudnorm em duas passagens: −16 LUFS / −1 dBTP
        r = subprocess.run(['ffmpeg', '-v', 'info', '-i', raw, '-af', 'loudnorm=I=-16:TP=-1:LRA=9:print_format=json', '-f', 'null', '-'],
                           capture_output=True, text=True)
        j = json.loads(r.stderr[r.stderr.rfind('{'):])
        af = (f"loudnorm=I=-16:TP=-1:LRA=9:measured_I={j['input_i']}:measured_TP={j['input_tp']}:"
              f"measured_LRA={j['input_lra']}:measured_thresh={j['input_thresh']}:offset={j['target_offset']}:linear=true")
        tag = ('_com_voz' if V.any() else '_previa_sem_voz') + a.sufixo
        wav = os.path.join(a.saida, f"GMS_Audio{tag}.wav")
        run(['ffmpeg', '-v', 'error', '-y', '-i', raw, '-af', af, '-ar', '48000', wav])
        for v in a.video:
            base = os.path.basename(v).replace('_mudo', tag).replace('.mp4', '')
            out = os.path.join(a.saida, base + '.mp4')
            run(['ffmpeg', '-v', 'error', '-y', '-i', v, '-i', wav, '-map', '0:v', '-map', '1:a', '-c:v', 'copy',
                 '-c:a', 'aac', '-b:a', '192k', '-t', '62', out])
            print('vídeo:', out)
    print('áudio:', wav)
    for s in rel: print('  ', s)


if __name__ == '__main__':
    main()
