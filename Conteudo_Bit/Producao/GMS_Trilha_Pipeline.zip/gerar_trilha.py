#!/usr/bin/env python3
"""
GMS · Filme "A Linha" — trilha e efeitos sonoros 100% sintetizados (sem direitos autorais).
Tudo sincronizado com theme.ts: 30 fps, 120 BPM (1 tempo = 0,5 s), 62 s.

Gera:  stems/music.wav  stems/sfx.wav  (estéreo 44,1 kHz, sem voz)
       cue_sheet.md     (tabela de cada efeito com tempo e quadro)
"""
import os, numpy as np
from scipy.signal import butter, sosfilt, sosfilt_zi
from scipy.io import wavfile

SR = 44100
DUR = 62.0
N = int(SR * DUR)
BEAT = 0.5
rng = np.random.default_rng(7)
HERE = os.path.dirname(os.path.abspath(__file__))
os.makedirs(f"{HERE}/stems", exist_ok=True)

# ------------------------------------------------------------------ utilidades
def buf(): return np.zeros((N, 2), dtype=np.float64)

def put(b, t, sig, gain=1.0, pan=0.0):
    """mistura 'sig' (mono) em b no tempo t (s). pan -1..1"""
    i = int(round(t * SR))
    if i >= N or i + len(sig) <= 0: return
    a = max(0, -i); e = min(len(sig), N - i)
    l = np.cos((pan + 1) * np.pi / 4); r = np.sin((pan + 1) * np.pi / 4)
    seg = sig[a:e] * gain
    b[i + a:i + e, 0] += seg * l
    b[i + a:i + e, 1] += seg * r

def tt(d): return np.arange(int(SR * d)) / SR
def env_exp(d, k): return np.exp(-k * tt(d))
def lp(x, fc, o=2): return sosfilt(butter(o, fc, 'low', fs=SR, output='sos'), x)
def hp(x, fc, o=2): return sosfilt(butter(o, fc, 'high', fs=SR, output='sos'), x)
def bp(x, a, b_, o=2): return sosfilt(butter(o, [a, b_], 'band', fs=SR, output='sos'), x)
def noise(d): return rng.standard_normal(int(SR * d))
def fade(x, a=0.003, z=0.01):
    x = x.copy(); na = int(a * SR); nz = int(z * SR)
    if na: x[:na] *= np.linspace(0, 1, na)
    if nz: x[-nz:] *= np.linspace(1, 0, nz)
    return x

def swept_noise(d, f0, f1, q=0.8, block=512):
    """ruído com passa-banda varrendo f0->f1 (whoosh/riser)."""
    n = int(SR * d); x = noise(d); y = np.zeros(n); zi = None
    for s in range(0, n, block):
        p = s / max(1, n - 1)
        fc = f0 * (f1 / f0) ** p
        lo = max(40, fc / (1 + q)); hi = min(SR / 2 - 100, fc * (1 + q))
        sos = butter(2, [lo, hi], 'band', fs=SR, output='sos')
        if zi is None: zi = [sosfilt_zi(sos[i:i + 1]) * 0 for i in range(len(sos))]
        seg = x[s:s + block]
        for i in range(len(sos)):
            seg, zi[i] = sosfilt(sos[i:i + 1], seg, zi=zi[i])
        y[s:s + block] = seg
    return y / (np.max(np.abs(y)) + 1e-9)

def midi(n): return 440.0 * 2 ** ((n - 69) / 12)

# ------------------------------------------------------------------ instrumentos
def kick(d=0.45, f0=170, f1=46):
    t = tt(d); f = f1 + (f0 - f1) * np.exp(-t * 28)
    ph = 2 * np.pi * np.cumsum(f) / SR
    x = np.sin(ph) * np.exp(-t * 7.5) + 0.35 * hp(noise(d), 2500) * np.exp(-t * 90)
    return fade(x, 0.0005, 0.02)

def hat(d=0.06, open_=False):
    d = 0.22 if open_ else d
    return fade(hp(noise(d), 7000) * env_exp(d, 38 if not open_ else 14), 0.0005, 0.01)

def clap(d=0.22):
    t = tt(d); x = bp(noise(d), 900, 4200)
    e = np.exp(-t * 22) + 0.6 * np.exp(-((t - 0.011) ** 2) / 3e-6) + 0.5 * np.exp(-((t - 0.022) ** 2) / 3e-6)
    return fade(x * e, 0.0005, 0.02)

def sub(note, d, vib=0):
    t = tt(d); f = midi(note)
    x = np.sin(2 * np.pi * f * t) + 0.25 * np.sin(4 * np.pi * f * t)
    return fade(x * np.minimum(1, t * 90) * np.exp(-t * 2.4), 0.002, 0.04)

def pluck(note, d=0.5, bright=0.5):
    t = tt(d); f = midi(note); x = 0
    for h, a in [(1, 1), (2, .5 * bright), (3, .35 * bright), (4, .2 * bright), (5, .1 * bright)]:
        x = x + a * np.sin(2 * np.pi * f * h * t + h)
    return fade(x * np.exp(-t * 9), 0.002, 0.03)

def pad(notes, d, att=0.5, rel=0.6, cutoff=1800):
    t = tt(d); x = np.zeros_like(t)
    for n in notes:
        f = midi(n)
        for det in (-0.07, 0.0, 0.07):  # 3 vozes levemente desafinadas
            fr = f * 2 ** (det / 12)
            for h in range(1, 7):
                x += np.sin(2 * np.pi * fr * h * t + rng.uniform(0, 6.28)) / h
    x = lp(x, cutoff)
    e = np.minimum(1, t / att) * np.minimum(1, (d - t) / rel)
    return x * e / (np.max(np.abs(x)) + 1e-9)

def blip(f=1400, d=0.07, g=1.0):
    t = tt(d); return fade(np.sin(2 * np.pi * f * t) * np.exp(-t * 55), 0.0005, 0.01) * g

def tick_soft(f=2400, d=0.03): return blip(f, d)

def whoosh(d=0.6, rising=True, f0=300, f1=6000):
    x = swept_noise(d, f0, f1) if rising else swept_noise(d, f1, f0)
    t = tt(d); p = t / d
    e = np.sin(np.pi * np.clip(p, 0, 1)) ** (1.6 if rising else 1.2)
    return x * e

def riser(d, f0=200, f1=5000, tone0=220, tone1=880):
    n = swept_noise(d, f0, f1, q=1.2)
    t = tt(d); p = t / d
    f = tone0 * (tone1 / tone0) ** p
    tone = np.sin(2 * np.pi * np.cumsum(f) / SR) * 0.35
    return (n * 0.8 + tone) * p ** 2.2

def impact(d=2.2, f0=95, f1=34, tail=1.0):
    t = tt(d); f = f1 + (f0 - f1) * np.exp(-t * 6)
    boom = np.sin(2 * np.pi * np.cumsum(f) / SR) * np.exp(-t * 2.2)
    air = lp(noise(d), 4500) * np.exp(-t * 5) * 0.5
    ring = (np.sin(2 * np.pi * midi(57) * t) + np.sin(2 * np.pi * midi(64) * t) * .6) * np.exp(-t * 3.0) * 0.12
    return fade(boom + air + ring, 0.001, 0.2)

def hit_small(d=0.5):
    t = tt(d); f = 60 + 90 * np.exp(-t * 30)
    x = np.sin(2 * np.pi * np.cumsum(f) / SR) * np.exp(-t * 9) + 0.3 * bp(noise(d), 1500, 6000) * np.exp(-t * 60)
    return fade(x, 0.0005, 0.03)

def reverse(x): return x[::-1]

def crash(d=1.6):
    return fade(hp(noise(d), 4500) * np.exp(-tt(d) * 2.6) * 0.8, 0.001, 0.1)

# ------------------------------------------------------------------ linha do tempo
CUTS = [0, 4, 10, 20, 26, 32, 38, 44, 52]            # início de cada cena (s)
cues = []                                             # (tempo, camada, descrição)
def cue(t, layer, desc): cues.append((t, layer, desc))

BARS = [  # acordes: (notas do pad, raiz do baixo, arpejo)
    ([57, 60, 64], 33, [57, 60, 64, 69]),   # Am
    ([53, 57, 60], 29, [53, 57, 60, 65]),   # F
    ([60, 64, 67], 36, [60, 64, 67, 72]),   # C
    ([55, 59, 62], 31, [55, 59, 62, 67]),   # G
]
def bar_at(t): return BARS[int(t // 2) % 4]

M = buf(); X = buf()

# ---- MÚSICA ------------------------------------------------------------------
# intensidade por trecho: 0 pad | 1 pulso | 2 groove | 3 groove cheio
def level(t):
    if t < 4: return 0
    if t < 10: return 2        # S02 flashes: pulso forte
    if t < 20: return 1        # S03 ondas: mais leve, arpejo
    if t < 44: return 3        # S04-S07
    if t < 52: return 1        # S08 números
    if t < 57: return 1        # S09 recomposição
    return 0

# pad contínuo (um acorde por compasso de 2 s), com volume variando por trecho
pad_gain = lambda t: 0.50 if t < 4 else 0.38 if t < 10 else 0.50 if t < 20 else 0.34 if t < 44 else 0.46 if t < 52 else 0.52
for bi in range(int(DUR // 2)):
    t0 = bi * 2.0
    notes, root, arp = bar_at(t0)
    if t0 >= 58.5:  # final: resolve em Am sustentado
        notes, root, arp = BARS[0]
    d = 2.3
    put(M, t0 - 0.15, pad(notes, d, att=0.45, rel=0.6), pad_gain(t0), pan=0.0)
cue(0.0, 'música', 'pad em Lá menor entra (Am–F–C–G, 1 acorde por compasso de 2 s)')

# bumbo, hat, palma, baixo, arpejo
for bi in range(int(DUR / BEAT)):
    t = bi * BEAT
    lv = level(t)
    notes, root, arp = bar_at(t)
    beat_in_bar = bi % 4
    if 4 <= t < 52 or False:
        if lv in (2, 3) or (lv == 1 and t < 20 and beat_in_bar in (0, 2)) or (lv == 1 and 44 <= t < 52 and beat_in_bar == 0):
            put(M, t, kick(), 0.85 if lv >= 2 else 0.55)
        # hat nos contratempos
        if lv in (2, 3):
            put(M, t + BEAT / 2, hat(), 0.22 if lv == 2 else 0.26, pan=0.3)
            if lv == 3: put(M, t, hat(), 0.10, pan=-0.3)
        if lv == 3 and beat_in_bar in (1, 3):
            put(M, t, clap(), 0.40, pan=0.0)
        if lv >= 2:
            # baixo: raiz no 1 e “and” do 3
            if beat_in_bar == 0: put(M, t, sub(root, 0.9), 0.55)
            if beat_in_bar == 2: put(M, t + BEAT / 2, sub(root + (7 if lv == 3 else 0), 0.45), 0.40)
        if lv == 1 and t < 20 and beat_in_bar == 0:
            put(M, t, sub(root, 1.6), 0.45)
    # arpejo em colcheias nos trechos 10–20 (suave) e 20–44 (mais cheio)
    if (10 <= t < 20) or (20 <= t < 44):
        step = 0.25 if t >= 20 else 0.5
        for j in range(int(BEAT / step)):
            tn = t + j * step
            k = int((tn / step)) % 4
            if (10 <= t < 20) and beat_in_bar % 2 == 1: continue
            put(M, tn, pluck(arp[k] + (12 if t >= 20 else 0), 0.40, 0.45), 0.12 if t >= 20 else 0.10, pan=-0.4 + 0.8 * (k % 2))
    # S08: pulsação de coração (bumbo suave no 1 e no 3) já coberto acima; S09: tick nos tempos

# S09: os 4 compassos antes do fecho ficam só com pad + ticks (silêncio dramático em 57–58)
cue(52.0, 'música', 'S08 termina; pulso baixo + pad; em 57,0 tudo cai para só o pad (silêncio dramático)')

# ---- EFEITOS (SFX) -----------------------------------------------------------
# S01: papel -> ponto vermelho -> abre
put(X, 0.05, lp(noise(0.9), 3000) * np.sin(np.pi * np.clip(tt(0.9) / 0.9, 0, 1)) ** 2, 0.10, pan=-0.3)
cue(0.05, 'sfx', 'farfalhar de papel (folhas)')
put(X, 0.9, riser(1.1, 300, 4200, 160, 640), 0.38)
cue(0.9, 'sfx', 'riser curto até o ponto vermelho nascer')
put(X, 2.0 - 0.01, hit_small(), 0.8)
put(X, 2.0, blip(880, 0.5, 0.0) + 0, 0.0)
put(X, 2.0, sub(45, 1.5), 0.55)
cue(2.0, 'sfx', 'ponto vermelho nasce (frame 60): hit + sub')
put(X, 1.87, whoosh(0.5, True, 400, 5000), 0.30)
cue(1.87, 'sfx', 'whoosh: ponto queima o papel (frames 56–70)')
put(X, 2.55, blip(1568, 0.25, 0.6), 0.25, pan=0.3)
put(X, 2.8, blip(1976, 0.25, 0.6), 0.22, pan=-0.3)
cue(2.55, 'sfx', 'dois pings de abertura: "From paper to live data."')

# cortes de cena: whoosh de entrada + impacto de corte
for k, c in enumerate(CUTS[1:], start=1):
    kind = ['flood', 'iris', 'portal', 'flood', 'iris', 'portal', 'flood', 'iris'][k - 1]
    if c == 52: continue  # S09 tem tratamento próprio
    wdur = 0.5
    put(X, c - 0.12, whoosh(wdur, True, 350, 7000) if kind != 'portal' else whoosh(wdur, False, 7000, 300), 0.5 if c >= 20 else 0.55)
    put(X, c, hit_small(), 0.55)
    if c in (4, 20, 44): put(X, c, crash(), 0.18, pan=0.2)
    cue(c - 0.12, 'sfx', f'whoosh de corte → S{k + 1:02d} ({kind}) + hit no corte')

# S02: 6 palavras, uma por segundo (4..9 s) com pitch subindo
words = ['PAPERLESS', 'TRACEABLE', 'LIVE', '8 STAGES', 'HOUR BY HOUR', '€0 CAPEX']
for i, w in enumerate(words):
    t = 4.0 + i
    put(X, t - 0.35, riser(0.35, 800, 5000, 300, 600 + 60 * i), 0.18)
    put(X, t, hit_small(), 0.65)
    put(X, t, clap(), 0.35)
    put(X, t + 0.02, blip(midi(69 + [0, 2, 4, 7, 9, 12][i]), 0.4, 0.5), 0.22, pan=(-1) ** i * 0.2)
    cue(t, 'sfx', f'flash "{w}": hit + palma + nota {i + 1}/6 subindo')

# S03: ondas (10, 12.5, 15.5, 18 s) + pilha de versões + teclas
for t, nm in [(12.5, 'Onda 2'), (15.5, 'Onda 3'), (18.0, 'HOJE')]:
    put(X, t - 0.1, whoosh(0.35, True, 500, 4500), 0.30)
    put(X, t, hit_small(), 0.45)
    cue(t, 'sfx', f'{nm}: whoosh curto + hit')
for t in [10.0 + 75 / 30 + 0.02, 10.0 + 120 / 30]:
    put(X, t, blip(1200, 0.12, 0.8), 0.2)
put(X, 18.0 + 0.0, blip(1760, 0.4, 0.8), 0.22)
# chips verdes (frames 172,187 da cena -> 15.73 s e 16.23 s)
for t in (10 + 172 / 30, 10 + 187 / 30):
    put(X, t, blip(1319, 0.18, 0.9), 0.28, pan=0.3); put(X, t + 0.06, blip(1760, 0.22, 0.9), 0.24, pan=0.3)
cue(10 + 172 / 30, 'sfx', 'chips verdes "✓ 2.854 achados" e "✓ 20 defeitos": ding duplo')
# digitação da tela de hoje (18–19,5 s): cliques suaves
for j in range(18):
    put(X, 18.3 + j * 0.075 + rng.uniform(0, 0.02), tick_soft(2600 + 400 * (j % 3), 0.025), 0.10, pan=rng.uniform(-0.3, 0.3))
cue(18.3, 'sfx', 'teclas de digitação (campos da Trançagem)')

# S04–S07: título entra (frame 8 da cena), câmera, cliques
for c, nm in [(20, 'S04'), (26, 'S05'), (32, 'S06'), (38, 'S07')]:
    put(X, c + 0.28, blip(1568, 0.25, 0.7), 0.20)
    put(X, c + 0.60, whoosh(0.5, True, 300, 3000), 0.12)       # tela sobe
    cue(c + 0.28, 'sfx', f'{nm}: título entra (ping) + tela sobe (whoosh leve)')
# S04: digitar OP e escolher carretel
for j in range(8): put(X, 21.4 + j * 0.09, tick_soft(2800, 0.025), 0.13)
put(X, 22.9, blip(990, 0.12, 0.9), 0.25); put(X, 23.9, blip(1320, 0.18, 0.9), 0.30)
cue(21.4, 'sfx', 'S04: digita a OP (8 teclas) · seleciona carretel · Start')
# S05: alerta do painel (parada sem motivo)
put(X, 29.0, blip(440, 0.25, 1.0), 0.30); put(X, 29.15, blip(440, 0.25, 1.0), 0.30)
cue(29.0, 'sfx', 'S05: alerta (dois bips graves) — "THXX parada sem motivo"')
# S06: 8 etapas varridas (uma nota por etapa)
for i in range(8):
    put(X, 33.0 + i * 0.28, blip(midi(60 + [0, 2, 4, 5, 7, 9, 11, 12][i]), 0.18, 0.9), 0.18, pan=-0.4 + 0.1 * i)
cue(33.0, 'sfx', 'S06: escala de 8 notas, uma por etapa')
# S07: alerta, dropdown, close shift
put(X, 40.0, blip(494, 0.28, 1.0), 0.28); put(X, 40.14, blip(494, 0.28, 1.0), 0.28)
put(X, 41.3, tick_soft(1900, 0.04), 0.22); put(X, 41.8, blip(1319, 0.2, 0.9), 0.28)
put(X, 42.9, blip(1047, 0.12, 0.9), 0.26); put(X, 43.05, blip(1568, 0.3, 0.9), 0.30)
cue(40.0, 'sfx', 'S07: alerta · abre motivos · escolhe "Reel change" · Close shift (confirmação)')

# S08: números a cada 2 s (44, 46, 48, 50)
for i, t in enumerate([44.0, 46.0, 48.0, 50.0]):
    put(X, t - 0.25, reverse(impact(0.6, 70, 40)) * 0.6, 0.35)
    put(X, t, impact(1.6, 85, 36), 0.60)
    put(X, t, hit_small(), 0.35)
    cue(t, 'sfx', f'S08: número {i + 1}/4 — swell reverso + impacto')
# 36× conta de 0 a 36: varredura de tom subindo (frames 1320..1362, entra com 'pop')
tC = 44.15; dC = 42 / 30
t_ = tt(dC); f_ = 300 * (1500 / 300) ** (t_ / dC)
put(X, tC, fade(np.sin(2 * np.pi * np.cumsum(f_) / SR) * 0.5, 0.005, 0.1), 0.18)
for j in range(14): put(X, tC + j * (dC / 14), tick_soft(1800 + 60 * j, 0.02), 0.14)
cue(tC, 'sfx', 'S08: contagem 0→36× — varredura de tom + 14 ticks')

# S09: riser, impacto no corte, ticks por etapa, "Paper forgets", GMS, remembers
put(X, 49.6, riser(2.4, 250, 7000, 180, 900), 0.55)
cue(49.6, 'sfx', 'riser longo (2,4 s) até o corte do fecho')
put(X, 52.0, impact(2.6, 100, 32), 0.75)
put(X, 51.93, whoosh(0.5, True, 300, 6500), 0.45)
put(X, 52.0, crash(2.0), 0.20)
cue(52.0, 'sfx', 'S09 entra: impacto grave + crash + whoosh')
# o anel recua para o ponto (frame 1560..1590) e redesenha uma etapa por tempo (1590..1710)
put(X, 52.2, reverse(whoosh(0.7, True, 300, 3000)), 0.25)
scale = [0, 2, 4, 7, 9, 12, 14, 16]  # escala maior subindo
for i in range(8):
    t = 53.0 + i * 0.5
    put(X, t, pluck(69 + scale[i], 0.6, 0.9), 0.30, pan=-0.5 + i / 8)
    put(X, t, tick_soft(3000, 0.02), 0.10)
    cue(t, 'sfx', f'S09: etapa {i + 1}/8 do carretel — nota {i + 1} da escala subindo')
# "Paper forgets." (57,0 s): cai tudo, nota grave
put(X, 57.0, impact(1.6, 70, 38), 0.45); cue(57.0, 'sfx', 'S09: "Paper forgets." — queda grave, música some')
# G, M, S (58,0 / 58,5 / 59,0 s)
for i, (t, n) in enumerate([(58.0, 57), (58.5, 60), (59.0, 64)]):
    put(X, t, hit_small(), 0.65)
    put(X, t, pluck(n + 12, 0.9, 1.0), 0.40)
    put(X, t, sub(n - 24, 0.6), 0.45)
    cue(t, 'sfx', f'S09: letra {"GMS"[i]} entra — hit + nota')
# "remembers." (59,5 s): acorde cheio + impacto longo
for n in (45, 57, 60, 64, 69):
    put(X, 59.5, pluck(n, 2.5, 0.8) * 1.0, 0.22)
put(X, 59.5, impact(2.5, 95, 30), 0.85)
put(X, 59.5, crash(2.5), 0.28)
cue(59.5, 'sfx', 'S09: "remembers." — acorde de Lá menor + impacto + crash; cauda até 62 s')

# ------------------------------------------------------------------ máscaras da música
def gain_curve(points):
    ts = np.arange(N) / SR
    return np.interp(ts, [p[0] for p in points], [p[1] for p in points])

mus_env = gain_curve([(0, 0.0), (0.4, 0.5), (1.9, 0.7), (4.0, 1.0), (50.0, 1.0), (52.0, 1.0),
                      (56.8, 0.9), (57.0, 0.35), (58.4, 0.35), (59.4, 0.5), (59.5, 0.7), (60.5, 0.45), (62.0, 0.0)])
M *= mus_env[:, None]

# levels relativos (música ~ -9 dB do SFX de pico) e proteção contra clip
def norm(b, peak): return b * (peak / (np.max(np.abs(b)) + 1e-9))
M = norm(M, 0.55)
X = norm(X, 0.80)
for nm, b in (('music', M), ('sfx', X)):
    wavfile.write(f"{HERE}/stems/{nm}.wav", SR, (np.clip(b, -1, 1) * 32767).astype(np.int16))

# ------------------------------------------------------------------ cue sheet
cues.sort()
with open(f"{HERE}/cue_sheet.md", 'w') as fh:
    fh.write("# Cue sheet — trilha e efeitos do filme GMS\n\n30 fps · 120 BPM · 62 s. Cada linha = um som sincronizado com a imagem.\n\n")
    fh.write("| Tempo | Quadro | Camada | O que toca |\n|---|---|---|---|\n")
    for t, l, d in cues:
        fh.write(f"| {t:6.2f} s | {int(round(t * 30)):4d} | {l} | {d} |\n")
print("ok:", len(cues), "cues")
