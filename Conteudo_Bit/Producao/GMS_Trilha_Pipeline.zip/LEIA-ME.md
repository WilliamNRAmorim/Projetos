# Como encaixar a sua voz

1. Grave um arquivo por bloco: S01.m4a … S09.m4a (textos em ../out/GMS_Filme_Roteiro_e_Tempos.md). 1 s de silêncio antes e depois.
2. Me mande os 9 arquivos. Eu rodo:
   python3 mix.py --voz PASTA --video ../out/GMS_Filme_EN_9x16_1080p_mudo.mp4 ../out/GMS_Filme_EN_16x9_1080p_mudo.mp4
3. O script apara o silêncio, trata a voz, posiciona cada bloco na sua cena, acelera no máximo 14 %, abaixa a música quando você fala e normaliza em −16 LUFS.
- Ajuste fino: --offset S09=56.7 (início absoluto, s) · --musica-db -3 · --sfx-db -2
- Cada efeito e o tempo dele: cue_sheet.md · trocar o clima: editar gerar_trilha.py e rodar de novo.
